# !/usr/bin/python
# coding=utf-8
import os
import sys
import getopt
from gspan import gSpan
from config import parser
from joblib import Parallel,delayed


FLAGS, unknown = parser.parse_known_args(args=sys.argv[1:])

reload(sys)
sys.setdefaultencoding('utf8')

def get_files_to_process(dirname, extn):
    files_to_process = [os.path.join(dirname, f) for f in os.listdir(dirname) if f.endswith(extn)]
    for root, dirs, files in os.walk(dirname):
        for f in files:
            if f.endswith(extn):
                files_to_process.append(os.path.join(root, f))

    files_to_process = list(set(files_to_process))
    return files_to_process

def process_single_fname(graph_file_name, FLAGS):
    value = graph_file_name.split('.')[-2]
    if value== 'train':
        output_subgraph_file_name = '../../graph_of_words/WebKB/graph_train.subgraph.s{}'.format(FLAGS.s)
        #output_vocab_file_name = '../../graph_of_words/WebKB/vocab_index.subgraph.s{}'.format(FLAGS.s)
    elif value== 'test':
        output_subgraph_file_name = '../../graph_of_words/WebKB/graph_test.subgraph.s{}'.format(FLAGS.s)
    else:
        print '********************ERROR****************************'
    print output_subgraph_file_name

    gs = gSpan(
        database_file_name=graph_file_name,
        output_subgraph_file_name=output_subgraph_file_name,
        #output_vocab_file_name=output_vocab_file_name,
        min_support=FLAGS.s,
        min_num_vertices=FLAGS.l,
        max_num_vertices=FLAGS.u,
        max_ngraphs=FLAGS.n,
        is_undirected=(FLAGS.d == 1),
        verbose=(FLAGS.v != 0),
        visualize=(FLAGS.p != 0),
        where=(FLAGS.w != 1)
    )

    gs.run()
    gs.time_stats()




def main():

    if not os.path.exists(FLAGS.database_file_name):
        print('{} does not exist.'.format(FLAGS.database_file_name))
        sys.exit()

    extn = '.data'
    data_files_to_process = get_files_to_process(FLAGS.database_file_name, extn)

    for f in data_files_to_process:
        process_single_fname(f, FLAGS)

    #Parallel(n_jobs=1)(delayed(process_single_fname)(f, FLAGS) for f in data_files_to_process)




if __name__ == '__main__':
    main()
